-- 后台「直播管理」菜单和按钮权限（可重复执行）。admin 超级管理员自动拥有全部权限，其他角色在「角色管理」里勾选
INSERT IGNORE INTO sys_menu VALUES (2100, '直播管理', 0, 0, 'live', NULL, '', '', 1, 0, 'M', '0', '0', '', 'online', 'admin', sysdate(), '', NULL, '直播管理目录');
INSERT IGNORE INTO sys_menu VALUES (2101, '直播间', 2100, 1, 'room', 'live/room/index', '', 'LiveRoom', 1, 0, 'C', '0', '0', 'live:room:list', 'monitor', 'admin', sysdate(), '', NULL, '直播间管理');
INSERT IGNORE INTO sys_menu VALUES (2102, '直播场次', 2100, 2, 'session', 'live/session/index', '', 'LiveSession', 1, 0, 'C', '0', '0', 'live:session:list', 'chart', 'admin', sysdate(), '', NULL, '场次统计：峰值、停留时长');
INSERT IGNORE INTO sys_menu VALUES (2103, '评论记录', 2100, 3, 'comment', 'live/comment/index', '', 'LiveComment', 1, 0, 'C', '0', '0', 'live:comment:list', 'message', 'admin', sysdate(), '', NULL, '评论记录');
INSERT IGNORE INTO sys_menu VALUES (2104, '禁言名单', 2100, 4, 'mute', 'live/mute/index', '', 'LiveMute', 1, 0, 'C', '0', '0', 'live:mute:list', 'lock', 'admin', sysdate(), '', NULL, '影子禁言名单');
INSERT IGNORE INTO sys_menu VALUES (2105, '观众管理', 2100, 5, 'viewer', 'live/viewer/index', '', 'LiveViewer', 1, 0, 'C', '0', '0', 'live:viewer:list', 'peoples', 'admin', sysdate(), '', NULL, '观众：游客/玩家/水军');
INSERT IGNORE INTO sys_menu VALUES (2110, '直播间查询', 2101, 1, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:room:query', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2111, '直播间新增', 2101, 2, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:room:add', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2112, '直播间修改', 2101, 3, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:room:edit', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2113, '直播间删除', 2101, 4, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:room:remove', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2114, '推流地址和链接', 2101, 5, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:room:push', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2115, '显示人数调整', 2101, 6, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:room:online', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2116, '推流开关和重新生成', 2101, 7, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:room:pushManage', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2120, '禁言', 2104, 1, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:mute:add', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2121, '解除禁言', 2104, 2, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:mute:remove', '#', 'admin', sysdate(), '', NULL, '');
INSERT IGNORE INTO sys_menu VALUES (2122, '水军管理', 2105, 1, '#', '', '', '', 1, 0, 'F', '0', '0', 'live:viewer:robot', '#', 'admin', sysdate(), '', NULL, '创建水军/换昵称/换头像/删除');
-- 隐藏「若依官网」外链菜单
UPDATE sys_menu SET visible = '1' WHERE menu_id = 4;
